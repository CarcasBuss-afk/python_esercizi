# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: creiamo funzioni con return e usiamo i valori restituiti """

# DEFINISCI UNA FUNZIONE chiamata 'calcola_sconto' che prende due parametri (prezzo, sconto_percentuale)
# e RESTITUISCE il prezzo scontato: prezzo - (prezzo * sconto_percentuale / 100)
___ calcola_sconto(______, __________________):
    prezzo_scontato = ______ - (______ * __________________ / 100)
    ______ prezzo_scontato


# Usa la funzione e salva il risultato
prezzo_finale = calcola_sconto(100, 20)
print(f"Prezzo finale: {____________} euro")

print("\n--- Separatore ---\n")

# DEFINISCI UNA FUNZIONE chiamata 'area_cerchio' che prende il parametro 'raggio'
# e RESTITUISCE l'area: 3.14 * raggio * raggio




# Usa la funzione per calcolare l'area di un cerchio con raggio 5
area1 = ___________(_)
print(f"Area del cerchio 1: {_____}")

# Usa di nuovo la funzione con raggio 10
area2 = ___________(___)
print(f"Area del cerchio 2: {_____}")

print("\n--- Operazioni con i valori restituiti ---\n")

# Ora usiamo i valori salvati per fare altri calcoli!
# Calcoliamo la somma delle due aree
somma_aree = _____ + _____
print(f"Somma delle due aree: {__________}")

# Calcoliamo la differenza delle due aree
differenza_aree = _____ - _____
print(f"Differenza delle due aree: {_______________}")

""" Osserva come i valori ritornati possono essere riutilizzati per altri calcoli! """
