# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: creiamo una funzione che calcola l'area di un quadrato dato il lato """

# DEFINISCI UNA FUNZIONE chiamata 'area_quadrato' che prende il parametro 'lato'
# e stampa "L'area del quadrato è [lato * lato]"
___ area_quadrato(____):
    area = ____ * ____
    print(f"L'area del quadrato è {____}")


# CHIAMA LA FUNZIONE area_quadrato TRE VOLTE con i valori 5, 8 e 12




# DEFINISCI UNA FUNZIONE chiamata 'presenta_citta' che prende il parametro 'citta'
# e stampa "Vivo a [citta]"




# CHIAMA LA FUNZIONE presenta_citta DUE VOLTE con "Roma" e "Milano"



""" Prova con valori diversi """
