# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: usiamo il valore restituito da una funzione in altri calcoli """

# DEFINISCI UNA FUNZIONE chiamata 'converti_celsius_fahrenheit' che prende 'celsius'
# e RESTITUISCE (celsius * 9/5) + 32
___ converti_celsius_fahrenheit(_______):
    fahrenheit = (_______ * _ / _) + __
    ______ __________


# Chiedi all'utente una temperatura in Celsius


# Converti in numero
celsius = float(__________)

# Usa la funzione per convertire
fahrenheit = ________________________(_______)

# STAMPA il risultato


""" Prova con temperature diverse """
