# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: creiamo funzioni con due e tre parametri """

# DEFINISCI UNA FUNZIONE chiamata 'moltiplica' che prende due parametri (a, b)
# e stampa "a * b = risultato"
___ moltiplica(_, _):
    risultato = _ * _
    print(f"{_} * {_} = {_________}")


# CHIAMA LA FUNZIONE moltiplica TRE VOLTE con (4, 5), (7, 8) e (10, 10)




# DEFINISCI UNA FUNZIONE chiamata 'presentazione' che prende tre parametri (nome, eta, citta)
# e stampa "Mi chiamo [nome], ho [eta] anni e vivo a [citta]"




# CHIAMA LA FUNZIONE presentazione DUE VOLTE con:
# ("Mario", 25, "Roma") e ("Anna", 30, "Milano")



""" Prova con valori diversi """
