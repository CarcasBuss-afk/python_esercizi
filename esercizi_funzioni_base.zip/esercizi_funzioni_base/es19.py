# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: creiamo funzioni che restituiscono valori e li usiamo """

# DEFINISCI UNA FUNZIONE chiamata 'calcola_imc' che prende due parametri (peso, altezza)
# e RESTITUISCE l'IMC: peso / (altezza * altezza)
___ calcola_imc(____, _______):
    imc = ____ / (_______ * _______)
    ______ ___


# Chiedi all'utente il peso in kg


# Chiedi all'utente l'altezza in metri


# Converti in numeri
peso = float(_________)
altezza = float(___________)

# Usa la funzione per calcolare l'IMC
imc = ___________(____, _______)

# STAMPA il risultato con 2 decimali


# Classifichiamo l'IMC
if imc _ 18.5:
    print("Sottopeso")
____ imc _ 25:
    print("Normopeso")
____:
    print("Sovrappeso")

""" Prova con peso e altezza diverse """
