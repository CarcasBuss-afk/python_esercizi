# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: impariamo a creare funzioni con UN PARAMETRO """

# I PARAMETRI permettono di passare valori alle funzioni
# Sintassi: def nome_funzione(parametro):
#               usa il parametro nel codice
#
# Quando chiami la funzione, passi il valore: nome_funzione(valore)

# Definiamo una funzione che accetta un nome come parametro
def saluta(nome):
    print(f"Ciao {nome}!")
    print(f"Benvenuto, {nome}!")

# Chiamiamo la funzione passando diversi nomi
saluta("Mario")
saluta("________")
saluta("Anna")

print("\n--- Separatore ---\n")

# Definiamo una funzione che calcola il quadrato di un numero
___ calcola_quadrato(numero):
    risultato = numero * ______
    print(f"Il quadrato di {______} è {risultato}")

# Chiamiamo la funzione con diversi numeri
calcola_quadrato(5)
________________(__)
calcola_quadrato(10)

# DEFINISCI UNA FUNZIONE chiamata 'raddoppia' che prende un numero e stampa il suo doppio




# CHIAMA LA FUNZIONE raddoppia DUE VOLTE: prima con il numero 7, poi con il numero 15



""" Osserva come la funzione usa valori diversi ogni volta """
