# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: creiamo tre funzioni diverse senza parametri e le chiamiamo in ordine """

# Definiamo una funzione chiamata 'benvenuto'
___ benvenuto():
    print("Benvenuto nel programma!")

# Definiamo una funzione chiamata 'mostra_menu'
___ __________():
    print("1. Opzione A")
    print("2. Opzione B")
    print("3. Esci")

# DEFINISCI UNA FUNZIONE chiamata 'arrivederci' che stampa "Grazie e arrivederci!"




# Ora chiamiamo le tre funzioni in sequenza
print("=== Inizio programma ===\n")

benvenuto()
print()
__________()
print()
___________()

print("\n=== Fine programma ===")

""" Esegui il programma e osserva l'ordine di esecuzione """
