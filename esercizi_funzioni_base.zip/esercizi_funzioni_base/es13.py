# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: creiamo una funzione e la chiamiamo con valori inseriti dall'utente """

# DEFINISCI UNA FUNZIONE chiamata 'calcola_area_triangolo' che prende due parametri (base, altezza)
# e stampa "L'area del triangolo è [base * altezza / 2]"
___ calcola_area_triangolo(____, _______):
    area = ____ * _______ / 2
    print(f"L'area del triangolo è {____}")


# CHIEDI ALL'UTENTE di inserire la base del triangolo


# CHIEDI ALL'UTENTE di inserire l'altezza del triangolo


# CONVERTI I VALORI IN NUMERI (usa float)
base = float(__________)
altezza = float(__________)

# CHIAMA LA FUNZIONE calcola_area_triangolo con i valori inseriti


""" Prova con valori diversi """
