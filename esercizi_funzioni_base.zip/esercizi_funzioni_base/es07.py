# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: creiamo una funzione che classifica l'età in categorie """

# DEFINISCI UNA FUNZIONE chiamata 'classifica_eta' che prende il parametro 'eta'
___ classifica_eta(___):
    # Se l'età è minore di 18, stampa "Sei minorenne"
    if ___ < 18:
        print("Sei __________")
    # Se l'età è tra 18 e 65, stampa "Sei adulto"
    ____ ___ <= 65:
        print("Sei ______")
    # Altrimenti stampa "Sei anziano"
    ____:
        print("Sei _______")


# CHIAMA LA FUNZIONE classifica_eta TRE VOLTE con le età 15, 30 e 70




""" Prova con età diverse """
