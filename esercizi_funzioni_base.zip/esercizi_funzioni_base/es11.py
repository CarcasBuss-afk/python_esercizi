# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: creiamo una funzione che calcola la media di due numeri """

# DEFINISCI UNA FUNZIONE chiamata 'media' che prende due parametri (num1, num2)
___ media(____, ____):
    # Calcola la media
    risultato = (____ + ____) / 2
    # Stampa il risultato
    print(f"La media di {____} e {____} è {_________}")


# CHIAMA LA FUNZIONE media TRE VOLTE con (10, 20), (15, 25) e (8, 12)




# DEFINISCI UNA FUNZIONE chiamata 'scheda_libro' che prende tre parametri (titolo, autore, anno)
# e stampa:
# "Libro: [titolo]"
# "Autore: [autore]"
# "Anno: [anno]"




# CHIAMA LA FUNZIONE scheda_libro DUE VOLTE con:
# ("1984", "George Orwell", 1949) e ("Il Signore degli Anelli", "J.R.R. Tolkien", 1954)



""" Prova con libri diversi """
