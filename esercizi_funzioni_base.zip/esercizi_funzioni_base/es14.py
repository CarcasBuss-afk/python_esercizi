# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: creiamo una funzione con tre parametri che usa if/else e input dell'utente """

# DEFINISCI UNA FUNZIONE chiamata 'verifica_accesso' che prende tre parametri (nome, eta, codice)
# Se età >= 18 E codice == "ABC123": stampa "[nome], accesso consentito"
# Altrimenti: stampa "[nome], accesso negato"
___ verifica_accesso(____, ___, ______):
    if ___ >= 18 ___ ______ == "ABC123":
        print(f"{____}, accesso __________")
    ____:
        print(f"{____}, accesso ______")


# CHIEDI ALL'UTENTE di inserire il nome


# CHIEDI ALL'UTENTE di inserire l'età


# CHIEDI ALL'UTENTE di inserire il codice


# CONVERTI L'ETÀ IN NUMERO INTERO
eta = int(_______)

# CHIAMA LA FUNZIONE verifica_accesso con i valori inseriti


""" Prova con età diverse e codici diversi """
