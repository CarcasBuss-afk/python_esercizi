# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: impariamo a creare funzioni con PIÙ PARAMETRI """

# Le funzioni possono accettare più parametri separati da virgola
# Sintassi: def nome_funzione(parametro1, parametro2, parametro3):
#               usa i parametri nel codice
#
# IMPORTANTE: l'ordine dei parametri conta!

# Definiamo una funzione che somma due numeri
def somma(a, b):
    risultato = a + b
    print(f"{a} + {b} = {risultato}")

# Chiamiamo la funzione con diversi valori
somma(5, 3)
somma(__, 15)
somma(100, ___)

print("\n--- Separatore ---\n")

# Definiamo una funzione che calcola l'area di un rettangolo
___ area_rettangolo(base, altezza):
    area = ____ * _______
    print(f"Area del rettangolo: {____}")

# Chiamiamo la funzione
area_rettangolo(5, 10)
________________(__, __)

# DEFINISCI UNA FUNZIONE chiamata 'sottrazione' che prende due numeri (a, b)
# e stampa "a - b = risultato"




# CHIAMA LA FUNZIONE sottrazione DUE VOLTE con (10, 3) e (50, 25)



""" Osserva come l'ordine dei parametri è importante! """
