# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: creiamo due funzioni e un menu che permette di scegliere quale eseguire """

# DEFINISCI UNA FUNZIONE chiamata 'mostra_info' che stampa "Programma versione 1.0"
___ mostra_info():
    print("__________ versione 1.0")


# DEFINISCI UNA FUNZIONE chiamata 'mostra_autore' che stampa "Creato da [tuo nome]"
___ ____________():
    print("Creato da ________")


# Creiamo il menu
print("=== MENU ===")
print("1. Mostra informazioni")
print("2. Mostra autore")
print("3. Esci")

# Chiediamo all'utente di scegliere
scelta = input("Scegli un'opzione (1/2/3): ")

# Verifichiamo la scelta e chiamiamo la funzione corrispondente
if scelta __ "1":
    __________()
elif scelta __ "__":
    ____________()
elif scelta __ "__":
    print("Arrivederci!")
else:
    print("Opzione ___ valida")

""" Prova tutte le opzioni del menu """
