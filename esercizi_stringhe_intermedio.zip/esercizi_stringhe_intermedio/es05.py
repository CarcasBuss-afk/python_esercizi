# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: chiediamo all'utente un nome utente. Rimuoviamo gli spazi all'inizio e alla fine.
Se la lunghezza del nome pulito è maggiore di 5 caratteri stampiamo "Nome accettato",
altrimenti "Nome troppo corto" """

# CHIEDI ALL'UTENTE DI INSERIRE IL NOME UTENTE


# Rimuoviamo gli spazi
nome_pulito = _______.strip()

# CALCOLA LA LUNGHEZZA DEL NOME PULITO


# VERIFICA SE LA LUNGHEZZA E' MAGGIORE DI 5 E STAMPA IL MESSAGGIO APPROPRIATO




""" Fai varie prove """
