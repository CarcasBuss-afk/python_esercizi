# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO del programma: chiediamo all'utente una password. Se la password è uguale a "python"
(ignorando maiuscole e minuscole), stampiamo "Accesso consentito", altrimenti "Accesso negato" """

# Chiedi all'utente di inserire la password
password = input("Inserisci la password: ")

# Il metodo .lower() converte tutti i caratteri di una stringa in minuscolo
# Convertiamo la password in minuscolo per poterla confrontare
password_minuscola = password.lower()

# Verifichiamo se la password è corretta
if password_minuscola __ "python":
    print("_______ consentito")
____:
    print("Accesso _______")

""" Prova con: Python, PYTHON, python, PyThOn """
