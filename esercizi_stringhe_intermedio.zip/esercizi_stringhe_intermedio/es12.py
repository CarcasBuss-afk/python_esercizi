# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: chiediamo all'utente il nome di un file. Verifichiamo se il file termina con '.txt'.
Se termina con '.txt' stampiamo "File di testo", altrimenti "Non è un file di testo" """

# Chiedi all'utente il nome del file
file = input("Inserisci il nome del file: ")

# Il metodo .endswith() verifica se una stringa termina con una determinata sottostringa
# Il metodo .startswith() verifica se una stringa inizia con una determinata sottostringa
# Verifichiamo se il file termina con '.txt'
if file.endswith("____"):
    print("File di _______")
____:
    print("___ è un file di testo")

""" Prova con: documento.txt, immagine.jpg, testo.txt """
