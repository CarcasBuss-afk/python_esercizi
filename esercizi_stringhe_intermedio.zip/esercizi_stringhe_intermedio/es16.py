# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: chiediamo all'utente una frase. Cerchiamo la posizione della parola 'python'.
Se troviamo 'python' stampiamo "Python trovato alla posizione X" (dove X è la posizione),
altrimenti "Python non trovato" """

# Chiedi all'utente di inserire una frase
frase = input("Inserisci una frase: ")

# Il metodo .find() cerca una stringa e restituisce la posizione dove inizia
# Se non la trova, restituisce -1
# Cerchiamo la posizione di 'python'
posizione = frase.find("______")

# Verifichiamo se è stato trovato
if posizione __ -1:
    print(f"Python trovato alla posizione {_________}")
____:
    print("Python ___ trovato")

""" Prova con: "Mi piace python", "python è bello", "Java è bello" """
