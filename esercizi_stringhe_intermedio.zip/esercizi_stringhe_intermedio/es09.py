# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: chiediamo all'utente una frase. Contiamo quante volte appare la lettera 'a'.
Se appare più di 3 volte stampiamo "Molte lettere a", altrimenti "Poche lettere a" """

# Chiedi all'utente di inserire una frase
frase = input("Inserisci una frase: ")

# Il metodo .count() conta quante volte una stringa appare dentro un'altra stringa
# Contiamo quante volte appare la lettera 'a'
numero_a = frase.count("a")

# Verifichiamo se ci sono più di 3 lettere 'a'
if numero_a _ 3:
    print("Molte lettere a")
____:
    print("______ lettere a")

""" Prova con frasi diverse """
