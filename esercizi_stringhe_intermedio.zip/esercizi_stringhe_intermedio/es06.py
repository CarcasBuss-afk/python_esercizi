# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: chiediamo all'utente un indirizzo email. Verifichiamo se contiene il simbolo '@'.
Se lo contiene stampiamo "Email valida", altrimenti "Email non valida" """

# Chiedi all'utente di inserire l'email
email = input("Inserisci la tua email: ")

# L'operatore 'in' verifica se una stringa è contenuta dentro un'altra stringa
# Verifichiamo se '@' è contenuto nell'email
if "@" in email:
    print("Email ______")
____:
    print("Email ___ valida")

""" Prova con diverse email """
