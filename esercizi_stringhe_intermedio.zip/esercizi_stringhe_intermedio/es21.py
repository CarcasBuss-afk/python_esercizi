# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: chiediamo all'utente una password. La password è valida se:
- contiene almeno 8 caratteri
- contiene il simbolo '@'
Se entrambe le condizioni sono vere stampiamo "Password valida", altrimenti "Password non valida" """

# Chiedi all'utente di inserire una password
password = input("Inserisci una password: ")

# Calcoliamo la lunghezza
lunghezza = len(________)

# Verifichiamo se la password è valida
if lunghezza __ 8 ___ "@" __ password:
    print("Password ______")
____:
    print("Password ___ valida")

""" Prova con: "abc@1234", "ciao@mondo", "breve", "lunghissima" """
