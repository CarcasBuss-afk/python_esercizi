# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: chiediamo all'utente una frase. Sostituiamo tutte le 'a' con '*'.
Se la frase modificata è diversa dalla frase originale stampiamo "Frase modificata",
altrimenti "Nessuna modifica" """

# Chiedi all'utente di inserire una frase
frase = input("Inserisci una frase: ")

# Il metodo .replace() sostituisce tutte le occorrenze di una stringa con un'altra
# Sostituiamo tutte le 'a' con '*'
frase_modificata = frase.replace("_", "_")

# Verifichiamo se la frase è cambiata
if frase_modificata __ frase:
    print("Frase __________")
    print(frase_modificata)
____:
    print("Nessuna _______")

""" Prova con frasi con e senza 'a' """
