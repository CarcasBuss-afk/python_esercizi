# Riepilogo completo
""" SCOPO: Chiedi all'utente un nome utente. Il nome utente è valido se:
- ha lunghezza tra 5 e 15 caratteri (dopo aver rimosso spazi)
- non contiene spazi dopo la pulizia
- inizia con una lettera (non un numero)
- contiene almeno un numero

Se tutte le condizioni sono vere stampa "Nome utente valido", altrimenti
stampa "Nome utente non valido" seguito dal motivo (es. "troppo corto",
"contiene spazi", "non inizia con lettera", "manca un numero") """

