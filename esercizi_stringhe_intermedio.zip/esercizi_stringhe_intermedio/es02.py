# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: chiediamo all'utente due parole. Confrontiamole ignorando maiuscole e minuscole.
Se sono uguali stampiamo "Le parole sono uguali", altrimenti "Le parole sono diverse" """

# CHIEDI ALL'UTENTE LA PRIMA PAROLA


# CHIEDI ALL'UTENTE LA SECONDA PAROLA


# Convertiamo entrambe in minuscolo
parola1_min = _______.lower()
_______ = parola2.______()

# CONFRONTA LE DUE PAROLE E STAMPA IL MESSAGGIO APPROPRIATO



""" Fai varie prove per verificare che funzioni """
