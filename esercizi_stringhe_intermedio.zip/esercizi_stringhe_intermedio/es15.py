# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: chiediamo all'utente una frase con la parola 'brutto'. Sostituiamo 'brutto' con 'bello'.
Contiamo quante volte abbiamo fatto la sostituzione. Se abbiamo sostituito più di 2 volte
stampiamo "Molte sostituzioni", se 1 o 2 volte "Poche sostituzioni", altrimenti "Nessuna sostituzione" """

# CHIEDI ALL'UTENTE DI INSERIRE UNA FRASE


# Contiamo quante volte appare 'brutto' prima di sostituirlo
sostituzioni = frase._____(______)

# Sostituiamo 'brutto' con 'bello'
frase_nuova = frase.replace(______, ______)

# VERIFICA QUANTE SOSTITUZIONI SONO STATE FATTE E STAMPA IL MESSAGGIO APPROPRIATO




# STAMPA LA FRASE NUOVA


""" Prova con frasi diverse """
