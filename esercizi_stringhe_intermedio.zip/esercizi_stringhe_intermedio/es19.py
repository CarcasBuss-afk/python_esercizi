# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: chiediamo all'utente una password. La password è valida se:
- il primo carattere è una lettera (non un numero)
- contiene almeno un numero da qualche parte
Se entrambe le condizioni sono vere stampiamo "Password valida", altrimenti "Password non valida" """

# CHIEDI ALL'UTENTE DI INSERIRE UNA PASSWORD


# Verifichiamo se il primo carattere è una lettera
primo_e_lettera = password[_].______()

# Verifichiamo se la password contiene almeno un numero
# Dobbiamo controllare ogni carattere della password
contiene_numero = False
for carattere in password:
    if carattere.______():
        contiene_numero = ____

# VERIFICA SE ENTRAMBE LE CONDIZIONI SONO VERE E STAMPA IL MESSAGGIO APPROPRIATO




""" Prova con: "Pass123", "123Pass", "Password", "P123" """
