# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: chiediamo all'utente una frase. Contiamo quanti spazi ci sono.
Se ci sono più di 5 spazi stampiamo "Frase lunga", se ci sono tra 2 e 5 spazi
stampiamo "Frase media", altrimenti stampiamo "Frase corta" """

# CHIEDI ALL'UTENTE DI INSERIRE UNA FRASE


# Contiamo gli spazi
numero_spazi = ______.count("_")

# Verifichiamo quanti spazi ci sono
if numero_spazi _ 5:
    print("Frase ______")
____ numero_spazi __ 2:
    print("Frase _____")
____:
    print("Frase ______")

""" Fai varie prove """
