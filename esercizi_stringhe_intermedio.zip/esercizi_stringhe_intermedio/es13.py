# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: chiediamo all'utente una frase. Verifichiamo se inizia con 'Ciao' e finisce con
un punto interrogativo '?'. Se entrambe le condizioni sono vere stampiamo "Domanda di saluto",
altrimenti "Non è una domanda di saluto" """

# CHIEDI ALL'UTENTE DI INSERIRE UNA FRASE


# Verifichiamo se inizia con 'Ciao' e finisce con '?'
if frase.________("Ciao") ___ frase.________("?"):
    print("Domanda di saluto")
____:
    print("___ è ___ domanda di saluto")

""" Prova con: "Ciao come stai?", "Ciao", "Come stai?", "Ciao!" """
