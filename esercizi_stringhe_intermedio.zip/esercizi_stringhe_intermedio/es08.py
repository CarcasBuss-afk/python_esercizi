# Riepilogo es06 e es07
""" SCOPO: Chiedi all'utente di inserire un URL. Verifica se l'URL contiene "https".
Se contiene "https" stampa "Connessione sicura", se contiene "http" (ma non "https")
stampa "Connessione non sicura", altrimenti stampa "URL non valido" """

