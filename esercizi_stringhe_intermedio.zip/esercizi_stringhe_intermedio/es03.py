# Riepilogo es01 e es02
""" SCOPO: Chiedi all'utente di inserire un comando (può essere 'avvia', 'ferma' o 'riavvia').
Confronta il comando ignorando maiuscole e minuscole. Se il comando è 'avvia' stampa
"Sistema avviato", se è 'ferma' stampa "Sistema fermato", se è 'riavvia' stampa
"Sistema riavviato", altrimenti stampa "Comando non riconosciuto" """

