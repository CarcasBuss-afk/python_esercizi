# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: chiediamo all'utente un codice. Rimuoviamo gli spazi all'inizio e alla fine.
Se il codice pulito è uguale a "ABC123" stampiamo "Codice valido", altrimenti "Codice non valido" """

# Chiedi all'utente di inserire il codice
codice = ______("Inserisci il codice: ")

# Il metodo .strip() rimuove gli spazi all'inizio e alla fine di una stringa
# Rimuoviamo gli spazi all'inizio e alla fine
codice_pulito = codice.strip()

# Verifichiamo se il codice è valido
__ codice_pulito == "_______":
    print("Codice valido")
____:
    print("______ non valido")

""" Prova inserendo: "ABC123", "  ABC123", "ABC123  ", "  ABC123  " """
