# Riepilogo es09 e es10
""" SCOPO: Chiedi all'utente di inserire un testo. Chiedi anche una lettera da cercare.
Conta quante volte quella lettera appare nel testo. Se appare 0 volte stampa "Lettera non trovata",
se appare 1 volta stampa "Lettera trovata una volta", altrimenti stampa
"Lettera trovata N volte" (dove N è il numero di volte) """

