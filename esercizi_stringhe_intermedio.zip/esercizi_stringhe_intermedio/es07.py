# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: chiediamo all'utente una frase. Chiediamo anche una parola da cercare.
Se la parola è contenuta nella frase stampiamo "Parola trovata", altrimenti "Parola non trovata" """

# CHIEDI ALL'UTENTE DI INSERIRE UNA FRASE


# CHIEDI ALL'UTENTE LA PAROLA DA CERCARE


# Verifichiamo se la parola è contenuta nella frase
__ ______ in ______:
    print("_______ trovata")
____:
    print("Parola ___ _______")

""" Fai varie prove """
