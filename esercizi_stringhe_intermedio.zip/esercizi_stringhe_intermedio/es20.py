# Riepilogo es18 e es19
""" SCOPO: Chiedi all'utente un codice prodotto. Il codice è valido se:
- inizia con esattamente 2 lettere maiuscole
- è seguito da esattamente 4 numeri
- la lunghezza totale è quindi 6 caratteri (es: "AB1234")

Se il codice è valido stampa "Codice prodotto valido", altrimenti stampa
"Codice prodotto non valido".

Suggerimento: usa lo slicing per separare le parti da controllare.
Esempi: "AB1234" valido, "A1234" non valido, "AB12" non valido, "ab1234" non valido """
