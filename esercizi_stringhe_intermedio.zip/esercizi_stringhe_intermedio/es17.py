# Riepilogo es16
""" SCOPO: Chiedi all'utente una frase. Chiedi anche una parola da cercare.
Cerca la posizione della parola nella frase. Se la trovi alla posizione 0
stampa "Parola all'inizio", se la trovi in qualsiasi altra posizione stampa
"Parola trovata alla posizione X", altrimenti stampa "Parola non trovata" """

