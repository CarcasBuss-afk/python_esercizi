# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: chiediamo all'utente un indirizzo email. Rimuoviamo spazi e convertiamo in minuscolo.
L'email è valida se:
- contiene '@'
- termina con '.com' o '.it'
Se l'email è valida stampiamo "Email valida", altrimenti "Email non valida" """

# CHIEDI ALL'UTENTE DI INSERIRE L'EMAIL


# Rimuoviamo spazi e convertiamo in minuscolo
email = email.______().______()

# Verifichiamo se contiene '@'
contiene_chiocciola = __ in ______

# Verifichiamo se termina con '.com' o '.it'
termina_bene = email.________(______) __ email.________(______)

# VERIFICA SE ENTRAMBE LE CONDIZIONI SONO VERE




""" Prova con diverse email """
