# Riepilogo es07 e es08
""" SCOPO: Chiedi all'utente una parola. Estrai ogni terzo carattere (posizioni 0, 3, 6, 9...).
Se il numero di caratteri estratti è maggiore di 3 stampa "Parola lunga",
altrimenti stampa "Parola corta". Stampa anche i caratteri estratti.

Esempio:
- Input: "Programmazione"
- Output caratteri estratti: "Prmzoe" (posizioni 0, 3, 6, 9, 12)
- Output: "Parola lunga"

Suggerimento: usa [::3] per estrarre ogni terzo carattere. """
