# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: chiediamo all'utente una stringa in formato CSV (valori separati da virgola).
Dividiamo la stringa, contiamo gli elementi e verifichiamo se ce ne sono almeno 3. """

# CHIEDI ALL'UTENTE DI INSERIRE UNA LISTA DI ELEMENTI SEPARATI DA VIRGOLA
# Esempio: "mela,banana,arancia,pera"


# Dividiamo la stringa usando la virgola come separatore
elementi = csv.split(___)
print(f"Elementi trovati: {________}")

# Contiamo gli elementi
numero_elementi = len(________)

# STAMPA IL NUMERO DI ELEMENTI


# Verifichiamo se ci sono almeno 3 elementi
__ numero_elementi __ 3:
    print("Ci sono almeno 3 elementi")
____:
    print("Ci sono _____ di 3 elementi")

""" Prova con: "rosso,verde,blu", "uno,due", "cane,gatto,topo,pesce" """
