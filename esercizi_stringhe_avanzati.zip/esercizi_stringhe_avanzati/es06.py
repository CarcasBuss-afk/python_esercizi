# Riepilogo es04 e es05
""" SCOPO: Chiedi all'utente una frase (con più parole). Inverti l'ordine dei caratteri
di OGNI SINGOLA PAROLA, ma mantieni l'ordine delle parole nella frase.

Esempio:
- Input: "Ciao mondo python"
- Output: "oaiC odnom nohtyp"

Suggerimento: usa .split() per dividere la frase in parole, poi inverti ogni parola,
e infine ricostruisci la frase. Usa un ciclo for per iterare sulle parole. """
