# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: chiediamo all'utente una lista di parole. Trasformiamo ogni parola in maiuscolo
e rimuoviamo gli spazi all'inizio e fine. Contiamo quante parole sono state modificate
(avevano spazi o lettere minuscole). """

# CHIEDI ALL'UTENTE UNA LISTA DI PAROLE SEPARATE DA VIRGOLA


# Dividiamo in lista
parole = lista.split(___)

# Trasformiamo ogni parola e contiamo le modifiche
parole_trasformate = []
modifiche = 0

for parola in ______:
    # Versione pulita
    parola_pulita = parola.______().______()
    parole_trasformate.append(_____________)

    # Verifichiamo se è cambiata
    if parola __ parola_pulita:
        modifiche = modifiche + __

# STAMPA LA LISTA ORIGINALE E QUELLA TRASFORMATA



# STAMPA IL NUMERO DI MODIFICHE


""" Prova con: "ciao, MONDO ,  python  , Code" """
