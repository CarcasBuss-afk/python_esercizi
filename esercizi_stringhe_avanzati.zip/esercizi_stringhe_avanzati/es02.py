# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: chiediamo all'utente una parola. Estraiamo le prime 3 lettere, le ultime 4 lettere,
e i caratteri dalla posizione 2 alla posizione 5. Stampiamo tutte le porzioni estratte. """

# CHIEDI ALL'UTENTE DI INSERIRE UNA PAROLA


# Estraiamo le prime 3 lettere
prime_tre = parola[___]
print(f"Prime 3 lettere: {_________}")

# Estraiamo le ultime 4 lettere
ultime_quattro = _____[____]
print(f"Ultime 4 lettere: {______________}")

# Estraiamo i caratteri dalla posizione 2 alla 5 (esclusa)
dal_2_al_5 = _____[___]
print(f"Dal 2 al 5: {__________}")

# STAMPA LA LUNGHEZZA TOTALE DELLA PAROLA


""" Prova con parole diverse, lunghe almeno 8 caratteri: "Computer", "Tecnologia", "Sviluppo" """
