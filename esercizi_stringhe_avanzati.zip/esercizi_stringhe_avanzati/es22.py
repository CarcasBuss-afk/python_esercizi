# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: impariamo a lavorare con LISTE DI STRINGHE.
Data una lista di nomi, contiamo quanti hanno più di 5 caratteri
e creiamo una nuova lista con solo quelli lunghi. """

# Una lista di stringhe è semplicemente una lista dove ogni elemento è una stringa
# Possiamo iterare sulla lista e applicare metodi delle stringhe a ogni elemento

nomi = ["Mario", "Alessandro", "Luca", "Francesca", "Giovanni", "Anna"]

print(f"Lista originale: {nomi}")

# Contiamo quanti nomi hanno più di 5 caratteri
contatore = 0
for nome in nomi:
    if len(nome) _ 5:
        contatore = contatore + 1

print(f"Nomi con più di 5 caratteri: {_________}")

# Creiamo una nuova lista con solo i nomi lunghi
nomi_lunghi = []
for nome in _____:
    if _____(nome) _ 5:
        nomi_lunghi._______(nome)

print(f"Lista nomi lunghi: {___________}")

# CHIEDI ALL'UTENTE DI INSERIRE UNA LISTA DI CITTÀ SEPARATE DA VIRGOLA


# Dividi in lista
citta = lista_citta.split(___)

# Conta quante città hanno più di 6 caratteri
contatore_citta = __
for _____ in citta:
    if _____(_____.strip()) _ 6:
        contatore_citta = contatore_citta + __

# STAMPA IL RISULTATO


""" Prova con diverse liste """
