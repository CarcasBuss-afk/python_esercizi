# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: chiediamo all'utente una parola. Invertiamola e confrontiamola con l'originale.
Se la parola è uguale alla sua versione invertita stampiamo "È un palindromo!",
altrimenti "Non è un palindromo". """

# CHIEDI ALL'UTENTE DI INSERIRE UNA PAROLA


# Convertiamo in minuscolo per confronto corretto
parola = parola.______()

# Invertiamo la parola
parola_invertita = ______[____]

# Confrontiamo la parola con la sua versione invertita
__ parola __ parola_invertita:
    print("È un palindromo!")
____:
    print("___ è un palindromo")

# STAMPA LA PAROLA ORIGINALE E QUELLA INVERTITA



""" Prova con: "radar", "anna", "casa", "osso", "python" """
