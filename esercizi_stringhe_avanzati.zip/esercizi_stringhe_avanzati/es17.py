# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: verifichiamo se una FRASE è un palindromo, ignorando gli spazi.
Esempio: "ai lati d itala" è un palindromo se rimuoviamo gli spazi. """

# CHIEDI ALL'UTENTE DI INSERIRE UNA FRASE


# Convertiamo in minuscolo
frase = frase.______()

# Rimuoviamo tutti gli spazi usando .replace()
frase_senza_spazi = frase._______(__ __, ___)

# Invertiamo la frase senza spazi
frase_invertita = ________________[____]

# Verifichiamo se è un palindromo
__ frase_senza_spazi __ frase_invertita:
    print(f"'{frase}' è un palindromo!")
____:
    print(f"'{frase}' non è un palindromo")

# STAMPA LA FRASE SENZA SPAZI E QUELLA INVERTITA



""" Prova con: "ai lati d itala", "oro", "anna", "ciao mondo" """
