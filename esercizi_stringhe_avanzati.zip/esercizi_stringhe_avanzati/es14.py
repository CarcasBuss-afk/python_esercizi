# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: chiediamo all'utente una frase. Dividiamola in parole, convertiamo ogni parola
in maiuscolo, e ricostruiamo la frase unendo le parole con un trattino "-". """

# CHIEDI ALL'UTENTE DI INSERIRE UNA FRASE


# Dividiamo la frase in parole
parole = frase.______()

# Creiamo una nuova lista dove ogni parola è in maiuscolo
# Usiamo un ciclo for
parole_maiuscole = []
for parola in ______:
    parole_maiuscole.append(______.______())

# Uniamo le parole con un trattino
frase_finale = _____.join(_______________)

# STAMPA LA FRASE ORIGINALE E QUELLA FINALE



""" Prova con: "ciao come stai oggi", "python è fantastico" """
