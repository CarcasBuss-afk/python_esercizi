# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: verifichiamo se due frasi sono anagrammi, ignorando spazi.
Esempio: "la mia rosa" e "lisa aroma" sono anagrammi. """

# CHIEDI ALL'UTENTE LA PRIMA FRASE


# CHIEDI ALL'UTENTE LA SECONDA FRASE


# Convertiamo in minuscolo e rimuoviamo gli spazi
frase1_pulita = frase1.______().replace(__ __, ___)
frase2_pulita = frase2.______().replace(__ __, ___)

# Ordiniamo le lettere
frase1_ordinata = ______(____________)
frase2_ordinata = ______(____________)

# Confrontiamo
__ frase1_ordinata __ frase2_ordinata:
    print(f"'{frase1}' e '{frase2}' sono anagrammi!")
____:
    print(f"'{frase1}' e '{frase2}' non sono anagrammi")

# STAMPA LE VERSIONI PULITE E ORDINATE



""" Prova con: "la mia rosa/lisa aroma", "ciao/oaic", "python/java" """
