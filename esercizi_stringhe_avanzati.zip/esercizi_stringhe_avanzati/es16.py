# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: impariamo a verificare se una parola è un PALINDROMO.
Un palindromo è una parola che si legge allo stesso modo da sinistra a destra
e da destra a sinistra. """

# ALGORITMO PALINDROMO
# Un palindromo è una stringa uguale alla sua versione invertita
# Esempi: "radar", "anna", "osso", "aba"
#
# Algoritmo:
# 1. Prendi la stringa
# 2. Invertila con [::-1]
# 3. Confrontala con l'originale
# 4. Se sono uguali, è un palindromo

parola = "radar"

# Invertiamo la parola
parola_invertita = parola[____]

# Confrontiamo
if parola __ parola_invertita:
    print(f"{parola} è un palindromo!")
____:
    print(f"{parola} ___ è un palindromo")

# CHIEDI ALL'UTENTE DI INSERIRE UNA PAROLA


# Convertiamo in minuscolo per confronto corretto
parola_utente = parola_utente.______()

# Verifica se è un palindromo
__ parola_utente == ______________[____]:
    print(f"{parola_utente} è un palindromo!")
____:
    print(f"{parola_utente} non è un palindromo")

""" Prova con: "radar", "python", "anna", "osso", "casa" """
