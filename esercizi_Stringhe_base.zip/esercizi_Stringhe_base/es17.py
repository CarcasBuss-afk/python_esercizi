# Riepilogo es14, es15 e es16
""" SCOPO: Chiediamo all'utente di inserire il suo soprannome. Trasformiamo il soprannome
in maiuscolo. Verifichiamo se il soprannome è più lungo di 10 caratteri. Se è più lungo
stampiamo 'Soprannome troppo lungo', altrimenti stampiamo 'Soprannome accettato' """

