# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: Aggiungiamo alla stessa stringa contenuta in una variabile il contenuto di un'altra
stringa contenuta in un'altra variabile"""

# Creo la variabile testo e gli metto una frase a piacere
testo = "_________________________"
# CREO LA VARIABILE aggiunta E GLI METTO UNA FRASE A PIACERE

# Aggiungo a testo il valore di aggiunta

______ += ______

# STAMPA IL VALORE DI testo

""" Avvia il programma e guarda il risultato """


