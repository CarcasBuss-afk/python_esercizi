# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: Chiediamo all'utente di inserire il nome di una città e calcoliamo la sua lunghezza """

# CHIEDI ALL'UTENTE DI INSERIRE IL NOME DI UNA CITTA'

# Calcola la lunghezza in caratteri della città. (Anche gli spazzi vengono calcolati)
# conserviamo il valore in una variabile
____________ = len(_____)

# STAMPA LA CITTA'

#Stampiamo il valore della lunghezza del nome della città
print(_____________________________)

""" ALLA FINE FAI UN PO' DI PROVE """
