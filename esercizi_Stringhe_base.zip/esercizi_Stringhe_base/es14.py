# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: convertiamo i caratteri di una stringa in MAIUSCOLO senza modificare la variabile
che la contiene"""

# Chiedi all'utente di inserire il nome di una nazione
nazione = _____("Inserisci il nome di una nazione: ")

# Stampa la variabile nazione in maiuscolo
print(nazione.upper())

# Stampa la variabile nazione
print(________)

""" Come potete notare la variabile nazione non è cambiata perchè il comando upper non
cambia direttamente il valore della variabile stessa """
