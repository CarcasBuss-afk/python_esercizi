# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: Aggiungiamo alla stessa stringa il valore di altre due stringhe. Fai in
modo che tra le parole ci sia sempre uno spazio"""

# creo una variabile e gli assegno una frase
messaggio = _____________________
#Aggiungo una città alla variabile messaggio
messaggio += "__________"

#Aggiungo una data alla variabile messaggio
____ __ "__________"

#STAMPA LA VARIABILE messaggio


""" Avvia il programma e guarda il risultato """
