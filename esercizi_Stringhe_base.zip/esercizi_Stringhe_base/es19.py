# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: chiediamo all'utente di inserire prima una città e poi una via in due variabili
diverse. Uniamo le iniziali delle due parole in una variabile denominata 'iniziali'
e stampiamole in MAIUSCOLO"""

# chiediamo all'utente la città
citta = _____________________________
# chiediamo all'utente la via
via = _____________________________

""" SUGGERIMENTO: in che posizione si trova la prima lettera di una stringa??? """
# Salviamo l'iniziale di città nella variabile 'inizCitta'
inizCitta = citta[__]
# Salviamo l'iniziale di via nella variabile 'inizVia'
inizVia = _______[__]

# Uniamo le due iniziali
iniziali = inizCitta __ _______

# STAMPIAMO LE INIZIALI IN MAIUSCOLO

""" Fai varie esecuzioni del programma e verifica se funziona correttamente """


