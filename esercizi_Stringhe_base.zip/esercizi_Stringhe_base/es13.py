# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: Chiediamo all'utente di inserire due nomi di animali e verifichiamo quale dei due nomi
è più lungo"""

# CHIEDI ALL'UTENTE DI INSERIRE IL NOME DI UN ANIMALE

# CHIEDI ALL'UTENTE DI INSERIRE IL NOME DI UN SECONDO ANIMALE

# CALCOLA LA LUNGHEZZA DEL PRIMO NOME

# CALCOLA LA LUNGHEZZA DEL SECONDO NOME

# Verifica quale dei due nomi è più lungo
if _______ > _______:
    print("Il primo nome è più lungo")
______
    print("Il secondo nome è più lungo")

""" Fai varie prove per verificare che il programma funzioni correttamente """
