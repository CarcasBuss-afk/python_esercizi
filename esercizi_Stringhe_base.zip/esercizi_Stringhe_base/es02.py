# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO del programma: uniamo due stringhe che rappresentano un colore e un animale.
Usa due stringhe a piacere! """

# Creo una variabile di tipo stringa e gli assegno un colore
________ = "______________________"
# Creo un'altra variabile di tipo stringa e gli assegno un animale
________ = ___________________________

# Creo la variabile 'descrizione' e gli assegno la somma delle due stringhe precedenti
descrizione = _________ + ________

# STAMPA IL RISULTATO
