# Riepilogo es01 e es02
""" SCOPO: Crea tre variabili di tipo stringa: una con il tuo cibo preferito, una con
la tua bevanda preferita e una con il tuo dessert preferito. Uniscile in una nuova stringa
e stampa il risultato. Fai in modo che non vengano attaccate e che ci sia uno spazio che le separa"""

