# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: Chiediamo all'utente di inserire un indirizzo email. Controlliamo se l'email è
più lunga di 30 caratteri. Se l'email è più lunga avvisiamo l'utente che l'email è troppo lunga,
altrimenti visualizziamo un messaggio di inserimento corretto """

# Chiediamo all'utente di inserire il proprio indirizzo email
email = ______("Inserisci il tuo indirizzo email: ")

# calcoliamo la lunghezza della stringa 'email' e mettiamo il valore nella variabile
# 'lunghezza'
lunghezza = _____________

# controlliamo che la lunghezza non sia maggiore di 30
if lunghezza > ___:
    print("L'email è troppo ________")
else:
    print("Inserimento ___________")

""" Esegui più volte il programma per verificare che rispetta lo scopo """
