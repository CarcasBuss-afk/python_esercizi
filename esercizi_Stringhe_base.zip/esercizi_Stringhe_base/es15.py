# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: convertiamo i caratteri di una stringa in MAIUSCOLO modificando anche il contenuto
della variabile"""

#Chiedi all'utente di inserire il nome di una marca
marca = input("__________________________________")

# Convertiamo il valore della variabile 'marca' in MAIUSCOLO in modo che la variabile marca
# è uguale alla variabile marca in maiuscolo. Sovrascrittura della variabile 'marca'
marca = ______.upper()

# STAMPA IL CONTENUTO DELLA VARIABILE marca


""" Esegui il programma e vedrai che questa volta il contenuto della variabile marca
è stato effettivamente cambiato """
