# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: stampiamo la prima, la quarta, la settima e l'ultima lettera della parola che trovi nella
variabile 'animale' """

animale = "Tartaruga"

"""Suggerimento: Le stringhe sono simili alle liste. Ogni carattere è come l'elemento di una lista"""
# Stampiamo il primo carattere ovvero quello in posizione 0
print(animale[0])

# Stampiamo il quarto carattere
_____(animale[__])

# stampiamo il settimo carattere
_____(______[__])

# STAMPA L'ULTIMO CARATTERE DELLA PAROLA

""" Esegui il programma e verifica il risultato """
