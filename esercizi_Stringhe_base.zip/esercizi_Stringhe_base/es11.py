# Riepilogo es09 e es10
""" SCOPO: Chiediamo all'utente di inserire una password. Calcoliamo e stampiamo
la lunghezza della password inserita. """

