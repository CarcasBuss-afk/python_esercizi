# Variazione del programma precedente

# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: Uniamo due stringhe in una nuova stringa.
Le due stringhe vengono richieste all'utente"""

# chiediamo il titolo di un libro all'utente
libro = input("_________ il titolo di un libro: ")
# chiediamo l'autore del libro all'utente
______ = input("________ l'________")
# uniamo le due stringhe in una nuova stringa
scheda = libro __ _______

# STAMPA IL RISULTATO


