# Riepilogo es18 e es19
""" SCOPO: Chiedi all'utente di inserire una parola qualsiasi. Prendi la prima, la terza
e l'ultima lettera della parola. Uniscile in una nuova variabile e stampa il risultato
in MAIUSCOLO. """

