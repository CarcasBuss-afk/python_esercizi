# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO del programma: uniamo due stringhe che rappresentano città e nazione """

# Creo la variabile citta e gli assegno una città
citta = "Vivo a ______!"
# Creo la variabile nazione e gli assegno una nazione
nazione = "Mi trovo in _________"

# Creo la variabile luogo e gli assegno la somma di citta + nazione
luogo = citta + _______

# STAMPA IL RISULTATO
__________________________



