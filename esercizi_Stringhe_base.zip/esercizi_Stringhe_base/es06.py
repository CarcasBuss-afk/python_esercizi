# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: Aggiungiamo alla stessa stringa una squadra di calcio preferita"""

# creo una variabile e gli assegno una frase
squadra = "La mia squadra del cuore è "

#Aggiungo il nome della squadra alla variabile squadra
# E' come fare l'incremento di una varibile di tipo intero
squadra += "__________"

#STAMPA LA VARIABILE squadra


""" Avvia il programma e guarda il risultato """
