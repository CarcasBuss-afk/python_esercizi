# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: Chiediamo all'utente di inserire il titolo di un film e calcoliamo la sua lunghezza """

# CHIEDI ALL'UTENTE DI INSERIRE IL TITOLO DI UN FILM
film = ____________________________________

# Calcola la lunghezza in caratteri del titolo. (Anche gli spazzi vengono calcolati)
# conserviamo il valore nella variabile lunghezza
lunghezza = len(film)

# STAMPA IL TITOLO DEL FILM

#Stampiamo il valore della lunghezza del titolo
print(f"Il titolo ha {_______} caratteri")

""" ALLA FINE FAI UN PO' DI PROVE """

