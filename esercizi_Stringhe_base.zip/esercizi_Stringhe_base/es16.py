# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: Chiediamo all'utente di inserire due parole. Uniamo le parole in una sola variabile di nome
'risultato'. Trasformiamo il valore di 'risultato' in maiuscolo. Alla fine contiamo il numero di caratteri
della parola unita"""

# Chiediamo all'utente di inserire una parola
parola1 = _____(________________________)

# CHIEDIAMO ALL'UTENTE DI INSERIRE UNA SECONDA PAROLA


# Uniamo le due parole in una variabile risultato
risultato = parola1 __  ______

# trasformiamo la variabile risultato in maiuscolo
________ = risultato._______()

# STAMPIAMO IL VALORE DELLA VARIABILE risultato


# STAMPIAMO LA LUNGHEZZA DEI CARATTERI DELLA PAROLA

""" Esegui più volte il programma per vedere gli effetti """

