# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: creiamo una funzione che analizza un numero e restituisce più informazioni """

# DEFINISCI UNA FUNZIONE chiamata 'analizza_numero' che prende un parametro 'numero'
# e RESTITUISCE tre valori:
# 1. Il doppio del numero (numero * 2)
# 2. Il quadrato del numero (numero * numero)
# 3. "pari" se il numero è pari, "dispari" se è dispari
___ analizza_numero(______):
    doppio = ______ * _
    quadrato = ______ * ______

    # Verifichiamo se è pari o dispari
    if ______ % _ == _:
        tipo = "_____"
    ____:
        tipo = "_______"

    ______ ______, ________, ____


# Chiedi all'utente di inserire un numero
input_num = input("Inserisci un numero: ")
numero = int(__________)

# Usa la funzione e fai l'unpacking
doppio_val, quadrato_val, tipo_numero = _______________(_______)

# STAMPA i risultati
print(f"Doppio: {__________}")
print(f"Quadrato: {____________}")
print(f"Il numero è {___________}")

""" Prova con numeri diversi: 5, 8, 12, 7 """
