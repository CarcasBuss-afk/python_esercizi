# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: creiamo un sistema di conversione temperature con funzioni composte """

# DEFINISCI UNA FUNZIONE chiamata 'celsius_to_kelvin' che prende 'celsius'
# e RESTITUISCE celsius + 273.15
___ celsius_to_kelvin(_______):
    ______ _______ + 273.15


# DEFINISCI UNA FUNZIONE chiamata 'celsius_to_fahrenheit' che prende 'celsius'
# e RESTITUISCE (celsius * 9/5) + 32
___ celsius_to_fahrenheit(_______):
    ______ (_______ * _ / _) + __


# DEFINISCI UNA FUNZIONE chiamata 'converti_tutto' che prende 'celsius'
# - Chiama celsius_to_kelvin e salva in 'kelvin'
# - Chiama celsius_to_fahrenheit e salva in 'fahrenheit'
# - Stampa tutte e tre le temperature in modo chiaro
___ converti_tutto(_______):
    kelvin = _________________(______)
    fahrenheit = ______________________(______)

    print(f"Temperatura in Celsius: {_______}°C")
    print(f"Temperatura in Kelvin: {______}K")
    print(f"Temperatura in Fahrenheit: {__________}°F")


# Chiedi all'utente una temperatura in Celsius


# Converti in numero
temp_celsius = float(__________)

# Chiama la funzione che usa le altre funzioni
____________(____________)

""" Prova con: 0, 25, 100, -40 """
