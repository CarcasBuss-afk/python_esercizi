# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: funzioni che analizzano e trasformano liste """

# DEFINISCI UNA FUNZIONE chiamata 'filtra_pari' che prende 'lista'
# e RESTITUISCE una NUOVA lista contenente solo i numeri pari
___ filtra_pari(_____):
    lista_pari = []
    for numero in _____:
        if numero _ _ __ _:
            lista_pari._______(______)
    ______ __________


# Lista di numeri
numeri = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# Filtra i pari
solo_pari = ____________(______)
print(f"Numeri pari: {__________}")

# DEFINISCI UNA FUNZIONE chiamata 'raddoppia_valori' che prende 'lista'
# e RESTITUISCE una nuova lista con tutti i valori raddoppiati




# Lista originale
prezzi = [10, 20, 30, 40]

# Raddoppia i prezzi
prezzi_doppi = ________________(_______)
print(f"Prezzi originali: {______}")
print(f"Prezzi raddoppiati: {_____________}")

# DEFINISCI UNA FUNZIONE chiamata 'trova_parole_lunghe' che prende 'lista_parole' e 'lunghezza_minima'
# e RESTITUISCE una lista con solo le parole che hanno lunghezza >= lunghezza_minima




# Lista di parole
parole = ["ciao", "programmazione", "python", "computer", "casa"]

# Trova parole lunghe (>= 7 caratteri)
parole_lunghe = ____________________(______, _)
print(f"Parole lunghe: {______________}")

""" Prova con liste diverse """
