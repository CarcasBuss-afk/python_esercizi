# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: creiamo funzioni con return multiplo usando parametri semplici """

# DEFINISCI UNA FUNZIONE chiamata 'calcola_rettangolo' che prende due parametri (base, altezza)
# e RESTITUISCE sia l'area (base * altezza) che il perimetro ((base + altezza) * 2)
___ calcola_rettangolo(____, _______):
    area = ____ * _______
    perimetro = (____ + _______) * 2
    ______ ____, _________


# Usa la funzione con base=10 e altezza=5
area_r, perimetro_r = ________________(__, _)
print(f"Area: {______}")
print(f"Perimetro: {___________}")

# DEFINISCI UNA FUNZIONE chiamata 'converti_secondi' che prende 'secondi_totali'
# Esempio: 125 secondi = 2 minuti e 5 secondi
# Formula: minuti = secondi_totali // 60 (divisione intera)
#          secondi_rimasti = secondi_totali % 60 (resto della divisione)
# RESTITUISCE: minuti e secondi_rimasti




# Chiedi all'utente quanti secondi vuole convertire (l'input restituisce una stringa)
input_secondi = input("Quanti secondi vuoi convertire? ")

# Converti la stringa in numero intero
secondi_totali = int(______________)

# Usa la funzione per convertire i secondi in minuti e secondi
minuti, secondi_rimasti = _______________(_______________)

# STAMPA il risultato nel formato "X minuti e Y secondi"


""" Prova con valori diversi: 125, 200, 75, 3665 """
