# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" Riepilogo: funzioni con return

Crea un programma per calcolare statistiche di un gioco.

Definisci queste funzioni:

1. calcola_punteggio_totale(livello1, livello2, livello3)
   - RESTITUISCE la somma dei tre punteggi

2. calcola_media_punteggi(totale, numero_livelli)
   - RESTITUISCE la media (totale / numero_livelli)

3. verifica_vittoria(punteggio_totale)
   - Se punteggio_totale >= 150: RESTITUISCE "Hai vinto!"
   - Altrimenti: RESTITUISCE "Riprova"

Il programma deve:
- Chiedere i punteggi dei 3 livelli
- Chiamare calcola_punteggio_totale e salvare il risultato
- Chiamare calcola_media_punteggi e salvare il risultato
- Chiamare verifica_vittoria e salvare il risultato
- Stampare: punteggio totale, media, e messaggio vittoria
"""

# DEFINISCI LE FUNZIONI QUI
















# SCRIVI IL PROGRAMMA PRINCIPALE QUI















