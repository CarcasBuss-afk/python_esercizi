# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: usare return in calcoli complessi """

# DEFINISCI UNA FUNZIONE chiamata 'calcola_prezzo_finale' che prende 'prezzo' e 'sconto'
# e RESTITUISCE il prezzo finale dopo lo sconto
# Formula: prezzo_finale = prezzo - (prezzo * sconto / 100)
___ ____________________(______, ______):
    ____________ = ______ - (______ * ______ / 100)
    ______ ____________


# DEFINISCI UNA FUNZIONE chiamata 'calcola_imc' che prende 'peso' e 'altezza'
# e RESTITUISCE l'indice di massa corporea (IMC)
# Formula: imc = peso / (altezza * altezza)
___ ___________(______, _______):
    ___ = ______ / (_______ * _______)
    ______ ___


# Programma principale
prezzo_originale = int(input("Prezzo originale: "))
percentuale_sconto = int(input("Sconto %: "))
# CHIAMA calcola_prezzo_finale
prezzo_scontato = ____________________(______________, __________________)
print("Prezzo finale: €", ______________)

peso_kg = int(input("Peso (kg): "))
altezza_m = float(input("Altezza (m): "))
# CHIAMA calcola_imc
imc = ___________(________, __________)
print("Il tuo IMC è:", ___)
