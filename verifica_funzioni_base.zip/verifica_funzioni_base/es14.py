# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: funzioni con validazione """

# DEFINISCI UNA FUNZIONE chiamata 'valida_voto' che prende 'voto'
# - Se voto >= 60: stampa "Promosso"
# - Altrimenti: stampa "Bocciato"
___ ___________(____):
    ____________
    ____________
    ____________


# DEFINISCI UNA FUNZIONE chiamata 'calcola_sconto_eta' che prende 'prezzo' e 'eta'
# - Se eta < 18: applica sconto 20% e stampa "Prezzo scontato: €[prezzo_scontato]"
# - Se eta >= 65: applica sconto 30% e stampa "Prezzo scontato: €[prezzo_scontato]"
# - Altrimenti: stampa "Prezzo pieno: €[prezzo]"
# Formula sconto: prezzo_scontato = prezzo - (prezzo * percentuale / 100)
___ _________________(______, ___):
    ____________
    ____________
    ____________
    ____________
    ____________
    ____________


# Programma principale
voto = int(input("Inserisci il voto: "))
# CHIAMA valida_voto
___________(_____)

prezzo_biglietto = int(input("Prezzo biglietto: "))
eta_utente = int(input("Età: "))
# CHIAMA calcola_sconto_eta
_________________(______________, __________)
