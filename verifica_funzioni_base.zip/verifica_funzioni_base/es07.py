# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: funzioni con logica condizionale """

# DEFINISCI UNA FUNZIONE chiamata 'verifica_maggiorenne' che prende 'eta'
# - Se eta >= 18: stampa "Sei maggiorenne"
# - Altrimenti: stampa "Sei minorenne"
___ ____________________(___):
    if ___ __ 18:
        print("Sei maggiorenne")
    ____:
        print("Sei minorenne")


# DEFINISCI UNA FUNZIONE chiamata 'verifica_temperatura' che prende 'gradi'
# - Se gradi > 30: stampa "Fa molto caldo"
# - Se gradi >= 20: stampa "Temperatura piacevole"
# - Altrimenti: stampa "Fa freddo"
___ ____________________(______):
    if ______ _ 30:
        ____________
    ____ ______ __ 20:
        ____________
    ____:
        ____________


# Programma principale
eta_input = input("Inserisci la tua età: ")
eta = int(__________)
# CHIAMA verifica_maggiorenne
____________________(___)

temp_input = input("Inserisci la temperatura: ")
gradi = int(__________)
# CHIAMA verifica_temperatura
____________________(______)
