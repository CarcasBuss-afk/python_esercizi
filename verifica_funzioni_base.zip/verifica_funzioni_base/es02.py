# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: creare funzioni e richiamarle multiple volte """

# DEFINISCI UNA FUNZIONE chiamata 'stampa_separatore' che stampa:
# "------------------------"
___ ________________():
    print("------------------------")


# DEFINISCI UNA FUNZIONE chiamata 'stampa_titolo_corso' che stampa:
# "CORSO DI PROGRAMMAZIONE PYTHON"
___ __________________():
    print("CORSO DI PROGRAMMAZIONE PYTHON")


# CHIAMA stampa_separatore
________________()

# CHIAMA stampa_titolo_corso
__________________()

# CHIAMA stampa_separatore di nuovo
________________()
