# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: funzioni che restituiscono un valore con return """

# DEFINISCI UNA FUNZIONE chiamata 'calcola_triplo' che prende 'numero'
# e RESTITUISCE il triplo del numero (numero * 3)
___ calcola_triplo(______):
    triplo = ______ * 3
    ______ ______


# DEFINISCI UNA FUNZIONE chiamata 'unisci_nomi' che prende 'nome' e 'cognome'
# e RESTITUISCE nome e cognome uniti (es. "Mario Rossi")
___ unisci_nomi(____, _______):
    nome_completo = ____ + " " + _______
    ______ _____________


# Programma principale
num = int(input("Inserisci un numero: "))
# CHIAMA calcola_triplo e salva il risultato in 'risultato'
risultato = _____________(___)
print("Il triplo è:", _________)

nome_input = input("Nome: ")
cognome_input = input("Cognome: ")
# CHIAMA unisci_nomi e salva il risultato in 'nome_completo'
nome_completo = ___________(__________, ______________)
print("Nome completo:", ______________)
