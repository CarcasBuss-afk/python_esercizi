# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: funzioni con parametri e calcoli """

# DEFINISCI UNA FUNZIONE chiamata 'calcola_perimetro_rettangolo' che prende 'base' e 'altezza'
# e stampa "Il perimetro è: [perimetro]"
# Formula: perimetro = (base + altezza) * 2
___ ____________________________(____, _______):
    _________ = (____ + _______) * 2
    print("Il perimetro è:", _________)


# DEFINISCI UNA FUNZIONE chiamata 'calcola_totale_con_iva' che prende 'prezzo' e 'iva'
# e stampa "Totale con IVA: €[totale]"
# Formula: totale = prezzo + (prezzo * iva / 100)
___ ______________________(______, ___):
    ______ = ______ + (______ * ___ / 100)
    print("Totale con IVA: €", ______)


# Programma principale
base = int(input("Base rettangolo: "))
altezza = int(input("Altezza rettangolo: "))
# CHIAMA calcola_perimetro_rettangolo
____________________________(_____, ______)

prezzo = int(input("Prezzo prodotto: "))
iva = int(input("Percentuale IVA: "))
# CHIAMA calcola_totale_con_iva
______________________(______, ___)
