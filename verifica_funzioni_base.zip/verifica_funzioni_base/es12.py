# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: funzioni con parametri e logica """

# DEFINISCI UNA FUNZIONE chiamata 'verifica_login' che prende 'username' e 'password'
# - Se username == "admin" E password == "1234": stampa "Accesso consentito"
# - Altrimenti: stampa "Accesso negato"
___ ______________(________, ________):
    if ________ __ "admin" ___ ________ __ "1234":
        print("Accesso consentito")
    ____:
        print("Accesso negato")


# DEFINISCI UNA FUNZIONE chiamata 'confronta_numeri' che prende 'a' e 'b'
# - Se a > b: stampa "[a] è maggiore di [b]"
# - Se a < b: stampa "[a] è minore di [b]"
# - Altrimenti: stampa "I numeri sono uguali"
___ ________________(_, _):
    if _ _ _:
        ____________
    ____ _ _ _:
        ____________
    ____:
        ____________


# Programma principale
user = input("Username: ")
pwd = input("Password: ")
# CHIAMA verifica_login
______________(_____, ___)

num_a = int(input("Primo numero: "))
num_b = int(input("Secondo numero: "))
# CHIAMA confronta_numeri
________________(_____, _____)
