# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: funzioni con parametro e calcoli """

# DEFINISCI UNA FUNZIONE chiamata 'calcola_area_quadrato' che prende 'lato'
# e stampa "L'area del quadrato è: [area]"
# Formula: area = lato * lato
___ calcola_area_quadrato(____):
    area = ____ * ____
    print("L'area del quadrato è:", ____)


# DEFINISCI UNA FUNZIONE chiamata 'converti_euro_dollari' che prende 'euro'
# e stampa "€[euro] corrispondono a $[dollari]"
# Formula: dollari = euro * 1.1
___ ______________________(____):
    ________ = ____ * 1.1
    print("€", ____, " corrispondono a $", ________)


# Programma principale
lato_input = input("Inserisci il lato del quadrato: ")
lato = int(__________)
# CHIAMA calcola_area_quadrato
____________________(____)

euro_input = input("Inserisci l'importo in euro: ")
euro = int(__________)
# CHIAMA converti_euro_dollari
______________________(____)
