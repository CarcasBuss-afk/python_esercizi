# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: usare i valori restituiti dalle funzioni """

# DEFINISCI UNA FUNZIONE chiamata 'calcola_area_cerchio' che prende 'raggio'
# e RESTITUISCE l'area (raggio * raggio * 3.14)
___ ____________________(______):
    area = ______ * ______ * 3.14
    ______ ____


# DEFINISCI UNA FUNZIONE chiamata 'converti_minuti_ore' che prende 'minuti'
# e RESTITUISCE le ore (minuti / 60)
___ ____________________(______):
    ore = ______ / 60
    ______ ___


# Programma principale
r = int(input("Raggio del cerchio: "))
# CHIAMA calcola_area_cerchio e salva in 'area'
____ = ____________________(__)
print("L'area del cerchio è:", ____)

m = int(input("Minuti: "))
# CHIAMA converti_minuti_ore e salva in 'ore'
___ = ____________________(_)
print(_, "minuti corrispondono a", ___, "ore")
