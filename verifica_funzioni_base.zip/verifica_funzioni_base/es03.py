# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: menu con funzioni """

# DEFINISCI UNA FUNZIONE chiamata 'mostra_menu' che stampa:
# "1. Visualizza prodotti"
# "2. Aggiungi al carrello"
# "3. Esci"
___ __________():
    ____________
    ____________
    ____________


# DEFINISCI UNA FUNZIONE chiamata 'mostra_prodotti' che stampa:
# "Prodotti disponibili: Laptop, Mouse, Tastiera"
___ ________________():
    ____________


# DEFINISCI UNA FUNZIONE chiamata 'mostra_carrello' che stampa:
# "Hai aggiunto un prodotto al carrello"
___ _______________():
    ____________


# DEFINISCI UNA FUNZIONE chiamata 'mostra_uscita' che stampa:
# "Grazie per gli acquisti!"
___ _____________():
    ____________


# Programma principale
# CHIAMA mostra_menu
__________()

scelta = input("\nScegli un'opzione: ")

if scelta __ "_":
    # CHIAMA mostra_prodotti
    ________________()
elif scelta __ "_":
    # CHIAMA mostra_carrello
    _______________()
elif scelta __ "_":
    # CHIAMA mostra_uscita
    _____________()
____:
    print("Opzione non valida")
