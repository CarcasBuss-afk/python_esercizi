# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: return con logica condizionale """

# DEFINISCI UNA FUNZIONE chiamata 'trova_massimo' che prende 'a' e 'b'
# e RESTITUISCE il numero più grande tra i due
___ _____________(_, _):
    if _ _ _:
        ______ _
    ____:
        ______ _


# DEFINISCI UNA FUNZIONE chiamata 'controlla_password' che prende 'password'
# - Se lunghezza >= 8: RESTITUISCE "Password sicura"
# - Altrimenti: RESTITUISCE "Password debole"
___ __________________(________):
    if len(________) __ 8:
        ______ "Password sicura"
    ____:
        ______ "Password debole"


# Programma principale
num1 = int(input("Primo numero: "))
num2 = int(input("Secondo numero: "))
massimo = _____________(_____, _____)
print("Il numero maggiore è:", ________)

pwd = input("Inserisci una password: ")
sicurezza = __________________(_____)
print(_________)
