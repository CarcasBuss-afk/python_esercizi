# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: funzioni con un parametro """

# DEFINISCI UNA FUNZIONE chiamata 'saluta_studente' che prende 'nome'
# e stampa "Ciao [nome], benvenuto al corso!"
___ saluta_studente(____):
    print("Ciao", ____, ", benvenuto al corso!")


# DEFINISCI UNA FUNZIONE chiamata 'calcola_doppio' che prende 'numero'
# e stampa il doppio del numero
# Formula: doppio = numero * 2
___ calcola_doppio(______):
    doppio = ______ * 2
    print("Il doppio è:", ______)


# Programma principale
nome_utente = input("Inserisci il tuo nome: ")
# CHIAMA saluta_studente passando nome_utente
________________(____________)

numero_utente = input("Inserisci un numero: ")
numero_int = int(______________)  # Convertiamo in intero
# CHIAMA calcola_doppio passando numero_int
______________(___________)
