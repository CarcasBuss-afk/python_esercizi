# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: funzioni con più parametri e calcoli complessi """

# DEFINISCI UNA FUNZIONE chiamata 'calcola_tempo_viaggio' che prende 'distanza' e 'velocita'
# e stampa "Tempo di viaggio: [tempo] ore"
# Formula: tempo = distanza / velocita
___ _____________________(________, ________):
    _____ = ________ / ________
    print("Tempo di viaggio:", _____, "ore")


# DEFINISCI UNA FUNZIONE chiamata 'calcola_calorie' che prende 'peso' e 'minuti'
# e stampa "Calorie bruciate: [calorie]"
# Formula: calorie = peso * minuti * 0.05
___ _______________(______, _______):
    ________ = ______ * _______ * 0.05
    print("Calorie bruciate:", ________)


# Programma principale
dist = int(input("Distanza (km): "))
vel = int(input("Velocità media (km/h): "))
# CHIAMA calcola_tempo_viaggio
_____________________(_____, ____)

peso = int(input("Peso corporeo (kg): "))
min_corsa = int(input("Minuti di corsa: "))
# CHIAMA calcola_calorie
_______________(_____, __________)
