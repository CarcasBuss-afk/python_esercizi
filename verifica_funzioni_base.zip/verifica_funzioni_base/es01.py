# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: creare e chiamare funzioni senza parametri """

# DEFINISCI UNA FUNZIONE chiamata 'mostra_benvenuto' che stampa:
# "=== BENVENUTO IN PALESTRA ==="
___ mostra_benvenuto():
    print("=== BENVENUTO IN PALESTRA ===")


# DEFINISCI UNA FUNZIONE chiamata 'mostra_orari' che stampa:
# "Orari: Lun-Ven 7:00-22:00"
___ mostra_orari():
    print("Orari: Lun-Ven 7:00-22:00")


# CHIAMA la funzione mostra_benvenuto
_____________()

# CHIAMA la funzione mostra_orari
_____________()
