# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" SCOPO: funzioni con due parametri """

# DEFINISCI UNA FUNZIONE chiamata 'stampa_studente' che prende 'nome' e 'corso'
# e stampa "Studente: [nome], Corso: [corso]"
___ stampa_studente(____, _____):
    print("Studente:", ____, ", Corso:", _____)


# DEFINISCI UNA FUNZIONE chiamata 'calcola_somma' che prende 'num1' e 'num2'
# e stampa "La somma è: [risultato]"
___ calcola_somma(____, ____):
    risultato = ____ + ____
    print("La somma è:", _________)


# Programma principale
nome_input = input("Inserisci nome studente: ")
corso_input = input("Inserisci nome corso: ")
# CHIAMA stampa_studente con nome_input e corso_input
________________(__________, ___________)

n1 = input("Inserisci primo numero: ")
n2 = input("Inserisci secondo numero: ")
num1 = int(__)
num2 = int(__)
# CHIAMA calcola_somma con num1 e num2
_____________(_____, _____)
