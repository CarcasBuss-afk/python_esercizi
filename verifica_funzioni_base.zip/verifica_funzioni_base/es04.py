# COMPLETA IL CODICE DOVE TROVI ________ !
# QUANDO CI SONO I COMMENTI IN MAIUSCOLO SIGINIFCA CHE DEVI SCRIVERE TU
# IL CODICE IN BASE A QUANTO RICHIESTO NEL COMMENTO

""" Riepilogo: funzioni senza parametri

Crea un piccolo programma per un cinema con queste funzioni:

1. mostra_titolo() - stampa "=== CINEMA CENTRAL ==="
2. mostra_film() - stampa "Film in programmazione: Matrix, Avatar, Inception"
3. mostra_orari() - stampa "Orari spettacoli: 15:00, 18:00, 21:00"
4. mostra_contatti() - stampa "Telefono: 123-456-789"

Il programma deve:
- Chiamare mostra_titolo
- Chiamare mostra_film
- Chiamare mostra_orari
- Chiamare mostra_contatti
"""

# DEFINISCI TUTTE LE FUNZIONI QUI








# SCRIVI IL PROGRAMMA PRINCIPALE QUI





